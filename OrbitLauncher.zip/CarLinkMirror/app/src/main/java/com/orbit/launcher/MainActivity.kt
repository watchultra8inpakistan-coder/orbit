package com.orbit.launcher

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.InputStream

class Lim(private val i: InputStream, private var n: Long, private val c: java.io.Closeable) : InputStream() {
    override fun read(): Int { if (n <= 0) return -1; val b = i.read(); if (b >= 0) n--; return b }
    override fun read(b: ByteArray, o: Int, l: Int): Int {
        if (n <= 0) return -1
        val r = i.read(b, o, minOf(l.toLong(), n).toInt()); if (r > 0) n -= r; return r
    }
    override fun close() { try { i.close() } catch (_: Exception) {}; try { c.close() } catch (_: Exception) {} }
}

class MainActivity : Activity() {
    private lateinit var wv: WebView

    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"").replace(Regex("[\\u0000-\\u001f]"), " ")

    inner class Bridge {
        @JavascriptInterface fun apps(): String {
            val pm = packageManager
            val li = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
            return li.joinToString(",", "[", "]") { "{\"n\":\"${esc(it.loadLabel(pm).toString())}\",\"p\":\"${it.activityInfo.packageName}\"}" }
        }
        @JavascriptInterface fun videos(): String {
            return try {
                val out = ArrayList<String>()
                contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE), null, null,
                    "${MediaStore.Video.Media.TITLE} COLLATE NOCASE"
                )?.use { c ->
                    while (c.moveToNext()) out.add("{\"id\":${c.getLong(0)},\"t\":\"${esc(c.getString(1) ?: "")}\"}")
                }
                out.joinToString(",", "[", "]")
            } catch (e: Exception) { "[]" }
        }
        @JavascriptInterface fun launch(p: String) {
            packageManager.getLaunchIntentForPackage(p)?.let { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(it) }
        }
        @JavascriptInterface fun songs(): String {
            return try {
                val out = ArrayList<String>()
                contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST),
                    "${MediaStore.Audio.Media.IS_MUSIC}!=0", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE"
                )?.use { c ->
                    while (c.moveToNext()) out.add("{\"id\":${c.getLong(0)},\"t\":\"${esc(c.getString(1) ?: "")}\",\"a\":\"${esc(c.getString(2) ?: "")}\"}")
                }
                out.joinToString(",", "[", "]")
            } catch (e: Exception) { "[]" }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        wv = WebView(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(wv)
        wv.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false; setGeolocationEnabled(true)
        }
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(o: String, cb: GeolocationPermissions.Callback) { cb.invoke(o, true, false) }
        }
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? = route(r)
        }
        val perms = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_EXTERNAL_STORAGE)
        requestPermissions(perms, 1)
        wv.loadUrl("https://orbit.app/index.html")
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        wv.evaluateJavascript("window.onPerm&&window.onPerm()", null)
    }

    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (wv.canGoBack()) wv.goBack() }

    private fun route(r: WebResourceRequest): WebResourceResponse? {
        if (r.url.host != "orbit.app") return null
        val p = r.url.path ?: "/"
        try {
            if (p == "/" || p == "/index.html") return WebResourceResponse("text/html", "utf-8", assets.open("index.html"))
            if (p.startsWith("/icon/")) {
                val d = packageManager.getApplicationIcon(p.removePrefix("/icon/"))
                val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
                d.setBounds(0, 0, 96, 96); d.draw(Canvas(bmp))
                val bo = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.PNG, 100, bo)
                return WebResourceResponse("image/png", null, ByteArrayInputStream(bo.toByteArray()))
            }
            if (p.startsWith("/song/")) return media(r, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, p.removePrefix("/song/").toLong(), "audio/mpeg")
            if (p.startsWith("/video/")) return media(r, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, p.removePrefix("/video/").toLong(), "video/mp4")
        } catch (_: Exception) { }
        return WebResourceResponse("text/plain", "utf-8", 404, "Not found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
    }

    private fun media(r: WebResourceRequest, base: android.net.Uri, id: Long, dm: String): WebResourceResponse {
        val uri = ContentUris.withAppendedId(base, id)
        val pfd = contentResolver.openFileDescriptor(uri, "r")!!
        val len = pfd.statSize
        val fis = FileInputStream(pfd.fileDescriptor)
        var start = 0L; var end = len - 1
        val rng = r.requestHeaders["Range"]
        if (rng != null) Regex("bytes=(\\d*)-(\\d*)").find(rng)?.let { m ->
            m.groupValues[1].toLongOrNull()?.let { start = it }
            m.groupValues[2].toLongOrNull()?.let { end = minOf(it, len - 1) }
        }
        fis.channel.position(start)
        val h = mapOf("Accept-Ranges" to "bytes", "Content-Length" to (end - start + 1).toString(), "Content-Range" to "bytes $start-$end/$len")
        return WebResourceResponse(contentResolver.getType(uri) ?: dm, null,
            if (rng != null) 206 else 200, if (rng != null) "Partial Content" else "OK", h, Lim(fis, end - start + 1, pfd))
    }
}
